﻿namespace kg_lab1
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDeffaultPosition = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.MoveTextBox = new System.Windows.Forms.TextBox();
            this.MovePlusX = new System.Windows.Forms.Button();
            this.MovePlusY = new System.Windows.Forms.Button();
            this.MovePlusZ = new System.Windows.Forms.Button();
            this.MoveMinusZ = new System.Windows.Forms.Button();
            this.MoveMinusY = new System.Windows.Forms.Button();
            this.MoveMinusX = new System.Windows.Forms.Button();
            this.RotateTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.RotateLeftZ = new System.Windows.Forms.Button();
            this.RotateLeftY = new System.Windows.Forms.Button();
            this.RotateLeftX = new System.Windows.Forms.Button();
            this.RotateRightZ = new System.Windows.Forms.Button();
            this.RotateRightY = new System.Windows.Forms.Button();
            this.RotateRightX = new System.Windows.Forms.Button();
            this.Stretch = new System.Windows.Forms.Button();
            this.Clench = new System.Windows.Forms.Button();
            this.taskOX = new System.Windows.Forms.Button();
            this.taskOY = new System.Windows.Forms.Button();
            this.taskOZ = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button1_exit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonDeffaultPosition
            // 
            this.buttonDeffaultPosition.Location = new System.Drawing.Point(10, 11);
            this.buttonDeffaultPosition.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDeffaultPosition.Name = "buttonDeffaultPosition";
            this.buttonDeffaultPosition.Size = new System.Drawing.Size(137, 24);
            this.buttonDeffaultPosition.TabIndex = 0;
            this.buttonDeffaultPosition.Text = "Стартовая позиция";
            this.buttonDeffaultPosition.UseVisualStyleBackColor = true;
            this.buttonDeffaultPosition.Click += new System.EventHandler(this.buttonDeffaultPosition_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 63);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Перемещение";
            // 
            // MoveTextBox
            // 
            this.MoveTextBox.Location = new System.Drawing.Point(14, 78);
            this.MoveTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.MoveTextBox.Name = "MoveTextBox";
            this.MoveTextBox.Size = new System.Drawing.Size(55, 20);
            this.MoveTextBox.TabIndex = 2;
            this.MoveTextBox.Text = "5";
            // 
            // MovePlusX
            // 
            this.MovePlusX.Location = new System.Drawing.Point(14, 100);
            this.MovePlusX.Margin = new System.Windows.Forms.Padding(2);
            this.MovePlusX.Name = "MovePlusX";
            this.MovePlusX.Size = new System.Drawing.Size(38, 24);
            this.MovePlusX.TabIndex = 3;
            this.MovePlusX.Text = "X";
            this.MovePlusX.UseVisualStyleBackColor = true;
            this.MovePlusX.Click += new System.EventHandler(this.MovePlusX_Click);
            // 
            // MovePlusY
            // 
            this.MovePlusY.Location = new System.Drawing.Point(63, 100);
            this.MovePlusY.Margin = new System.Windows.Forms.Padding(2);
            this.MovePlusY.Name = "MovePlusY";
            this.MovePlusY.Size = new System.Drawing.Size(38, 24);
            this.MovePlusY.TabIndex = 4;
            this.MovePlusY.Text = "Y";
            this.MovePlusY.UseVisualStyleBackColor = true;
            this.MovePlusY.Click += new System.EventHandler(this.MovePlusY_Click);
            // 
            // MovePlusZ
            // 
            this.MovePlusZ.Location = new System.Drawing.Point(112, 100);
            this.MovePlusZ.Margin = new System.Windows.Forms.Padding(2);
            this.MovePlusZ.Name = "MovePlusZ";
            this.MovePlusZ.Size = new System.Drawing.Size(38, 24);
            this.MovePlusZ.TabIndex = 5;
            this.MovePlusZ.Text = "Z";
            this.MovePlusZ.UseVisualStyleBackColor = true;
            this.MovePlusZ.Click += new System.EventHandler(this.MovePlusZ_Click);
            // 
            // MoveMinusZ
            // 
            this.MoveMinusZ.Location = new System.Drawing.Point(112, 130);
            this.MoveMinusZ.Margin = new System.Windows.Forms.Padding(2);
            this.MoveMinusZ.Name = "MoveMinusZ";
            this.MoveMinusZ.Size = new System.Drawing.Size(38, 24);
            this.MoveMinusZ.TabIndex = 8;
            this.MoveMinusZ.Text = "Z";
            this.MoveMinusZ.UseVisualStyleBackColor = true;
            this.MoveMinusZ.Click += new System.EventHandler(this.MoveMinusZ_Click);
            // 
            // MoveMinusY
            // 
            this.MoveMinusY.Location = new System.Drawing.Point(63, 130);
            this.MoveMinusY.Margin = new System.Windows.Forms.Padding(2);
            this.MoveMinusY.Name = "MoveMinusY";
            this.MoveMinusY.Size = new System.Drawing.Size(38, 24);
            this.MoveMinusY.TabIndex = 7;
            this.MoveMinusY.Text = "-Y";
            this.MoveMinusY.UseVisualStyleBackColor = true;
            this.MoveMinusY.Click += new System.EventHandler(this.MoveMinusY_Click);
            // 
            // MoveMinusX
            // 
            this.MoveMinusX.Location = new System.Drawing.Point(14, 130);
            this.MoveMinusX.Margin = new System.Windows.Forms.Padding(2);
            this.MoveMinusX.Name = "MoveMinusX";
            this.MoveMinusX.Size = new System.Drawing.Size(38, 24);
            this.MoveMinusX.TabIndex = 6;
            this.MoveMinusX.Text = "-X";
            this.MoveMinusX.UseVisualStyleBackColor = true;
            this.MoveMinusX.Click += new System.EventHandler(this.MoveMinusX_Click);
            // 
            // RotateTextBox
            // 
            this.RotateTextBox.Location = new System.Drawing.Point(13, 191);
            this.RotateTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.RotateTextBox.Name = "RotateTextBox";
            this.RotateTextBox.Size = new System.Drawing.Size(57, 20);
            this.RotateTextBox.TabIndex = 10;
            this.RotateTextBox.Text = "45\r\n";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(11, 176);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Вращение";
            // 
            // RotateLeftZ
            // 
            this.RotateLeftZ.Location = new System.Drawing.Point(110, 244);
            this.RotateLeftZ.Margin = new System.Windows.Forms.Padding(2);
            this.RotateLeftZ.Name = "RotateLeftZ";
            this.RotateLeftZ.Size = new System.Drawing.Size(38, 24);
            this.RotateLeftZ.TabIndex = 16;
            this.RotateLeftZ.Text = "Z-l";
            this.RotateLeftZ.UseVisualStyleBackColor = true;
            this.RotateLeftZ.Click += new System.EventHandler(this.RotateLeftZ_Click);
            // 
            // RotateLeftY
            // 
            this.RotateLeftY.Location = new System.Drawing.Point(61, 244);
            this.RotateLeftY.Margin = new System.Windows.Forms.Padding(2);
            this.RotateLeftY.Name = "RotateLeftY";
            this.RotateLeftY.Size = new System.Drawing.Size(38, 24);
            this.RotateLeftY.TabIndex = 15;
            this.RotateLeftY.Text = "Y-l";
            this.RotateLeftY.UseVisualStyleBackColor = true;
            this.RotateLeftY.Click += new System.EventHandler(this.RotateLeftY_Click);
            // 
            // RotateLeftX
            // 
            this.RotateLeftX.Location = new System.Drawing.Point(12, 244);
            this.RotateLeftX.Margin = new System.Windows.Forms.Padding(2);
            this.RotateLeftX.Name = "RotateLeftX";
            this.RotateLeftX.Size = new System.Drawing.Size(38, 24);
            this.RotateLeftX.TabIndex = 14;
            this.RotateLeftX.Text = "X-l";
            this.RotateLeftX.UseVisualStyleBackColor = true;
            this.RotateLeftX.Click += new System.EventHandler(this.RotateLeftX_Click);
            // 
            // RotateRightZ
            // 
            this.RotateRightZ.Location = new System.Drawing.Point(110, 215);
            this.RotateRightZ.Margin = new System.Windows.Forms.Padding(2);
            this.RotateRightZ.Name = "RotateRightZ";
            this.RotateRightZ.Size = new System.Drawing.Size(38, 24);
            this.RotateRightZ.TabIndex = 13;
            this.RotateRightZ.Text = "Z-r";
            this.RotateRightZ.UseVisualStyleBackColor = true;
            this.RotateRightZ.Click += new System.EventHandler(this.RotateRightZ_Click);
            // 
            // RotateRightY
            // 
            this.RotateRightY.Location = new System.Drawing.Point(61, 215);
            this.RotateRightY.Margin = new System.Windows.Forms.Padding(2);
            this.RotateRightY.Name = "RotateRightY";
            this.RotateRightY.Size = new System.Drawing.Size(38, 24);
            this.RotateRightY.TabIndex = 12;
            this.RotateRightY.Text = "Y-r";
            this.RotateRightY.UseVisualStyleBackColor = true;
            this.RotateRightY.Click += new System.EventHandler(this.RotateRightY_Click);
            // 
            // RotateRightX
            // 
            this.RotateRightX.Location = new System.Drawing.Point(12, 215);
            this.RotateRightX.Margin = new System.Windows.Forms.Padding(2);
            this.RotateRightX.Name = "RotateRightX";
            this.RotateRightX.Size = new System.Drawing.Size(38, 24);
            this.RotateRightX.TabIndex = 11;
            this.RotateRightX.Text = "X-r";
            this.RotateRightX.UseVisualStyleBackColor = true;
            this.RotateRightX.Click += new System.EventHandler(this.RotateRightX_Click);
            // 
            // Stretch
            // 
            this.Stretch.Location = new System.Drawing.Point(199, 81);
            this.Stretch.Margin = new System.Windows.Forms.Padding(2);
            this.Stretch.Name = "Stretch";
            this.Stretch.Size = new System.Drawing.Size(84, 24);
            this.Stretch.TabIndex = 20;
            this.Stretch.Text = "Увеличить";
            this.Stretch.UseVisualStyleBackColor = true;
            this.Stretch.Click += new System.EventHandler(this.Increase_Click);
            // 
            // Clench
            // 
            this.Clench.Location = new System.Drawing.Point(199, 109);
            this.Clench.Margin = new System.Windows.Forms.Padding(2);
            this.Clench.Name = "Clench";
            this.Clench.Size = new System.Drawing.Size(84, 24);
            this.Clench.TabIndex = 21;
            this.Clench.Text = "Уменьшить";
            this.Clench.UseVisualStyleBackColor = true;
            this.Clench.Click += new System.EventHandler(this.Reduce_Click);
            // 
            // taskOX
            // 
            this.taskOX.Location = new System.Drawing.Point(13, 283);
            this.taskOX.Margin = new System.Windows.Forms.Padding(2);
            this.taskOX.Name = "taskOX";
            this.taskOX.Size = new System.Drawing.Size(137, 24);
            this.taskOX.TabIndex = 22;
            this.taskOX.Text = "Вращение по OX";
            this.taskOX.UseVisualStyleBackColor = true;
            this.taskOX.Click += new System.EventHandler(this.animationOX_Click);
            // 
            // taskOY
            // 
            this.taskOY.Location = new System.Drawing.Point(13, 312);
            this.taskOY.Margin = new System.Windows.Forms.Padding(2);
            this.taskOY.Name = "taskOY";
            this.taskOY.Size = new System.Drawing.Size(137, 24);
            this.taskOY.TabIndex = 23;
            this.taskOY.Text = "Вращение по OY";
            this.taskOY.UseVisualStyleBackColor = true;
            this.taskOY.Click += new System.EventHandler(this.animationOY_Click);
            // 
            // taskOZ
            // 
            this.taskOZ.Location = new System.Drawing.Point(13, 341);
            this.taskOZ.Margin = new System.Windows.Forms.Padding(2);
            this.taskOZ.Name = "taskOZ";
            this.taskOZ.Size = new System.Drawing.Size(137, 24);
            this.taskOZ.TabIndex = 24;
            this.taskOZ.Text = "Вращение по OZ";
            this.taskOZ.UseVisualStyleBackColor = true;
            this.taskOZ.Click += new System.EventHandler(this.animationOZ_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(196, 63);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 13);
            this.label3.TabIndex = 25;
            this.label3.Text = "Масштабирование";
            // 
            // button1_exit
            // 
            this.button1_exit.Location = new System.Drawing.Point(81, 405);
            this.button1_exit.Margin = new System.Windows.Forms.Padding(2);
            this.button1_exit.Name = "button1_exit";
            this.button1_exit.Size = new System.Drawing.Size(137, 24);
            this.button1_exit.TabIndex = 27;
            this.button1_exit.Text = "Выход";
            this.button1_exit.UseVisualStyleBackColor = true;
            this.button1_exit.Click += new System.EventHandler(this.button1_exit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.buttonDeffaultPosition);
            this.panel1.Location = new System.Drawing.Point(2, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(309, 436);
            this.panel1.TabIndex = 28;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(611, 587);
            this.Controls.Add(this.button1_exit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.taskOZ);
            this.Controls.Add(this.taskOY);
            this.Controls.Add(this.taskOX);
            this.Controls.Add(this.Clench);
            this.Controls.Add(this.Stretch);
            this.Controls.Add(this.RotateLeftZ);
            this.Controls.Add(this.RotateLeftY);
            this.Controls.Add(this.RotateLeftX);
            this.Controls.Add(this.RotateRightZ);
            this.Controls.Add(this.RotateRightY);
            this.Controls.Add(this.RotateRightX);
            this.Controls.Add(this.RotateTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.MoveMinusZ);
            this.Controls.Add(this.MoveMinusY);
            this.Controls.Add(this.MoveMinusX);
            this.Controls.Add(this.MovePlusZ);
            this.Controls.Add(this.MovePlusY);
            this.Controls.Add(this.MovePlusX);
            this.Controls.Add(this.MoveTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ПИ-13 Габеркорн";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonDeffaultPosition;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox MoveTextBox;
        private System.Windows.Forms.Button MovePlusX;
        private System.Windows.Forms.Button MovePlusY;
        private System.Windows.Forms.Button MovePlusZ;
        private System.Windows.Forms.Button MoveMinusZ;
        private System.Windows.Forms.Button MoveMinusY;
        private System.Windows.Forms.Button MoveMinusX;
        private System.Windows.Forms.TextBox RotateTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button RotateLeftZ;
        private System.Windows.Forms.Button RotateLeftY;
        private System.Windows.Forms.Button RotateLeftX;
        private System.Windows.Forms.Button RotateRightZ;
        private System.Windows.Forms.Button RotateRightY;
        private System.Windows.Forms.Button RotateRightX;
        private System.Windows.Forms.Button Stretch;
        private System.Windows.Forms.Button Clench;
        private System.Windows.Forms.Button taskOX;
        private System.Windows.Forms.Button taskOY;
        private System.Windows.Forms.Button taskOZ;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1_exit;
        private System.Windows.Forms.Panel panel1;
    }
}

